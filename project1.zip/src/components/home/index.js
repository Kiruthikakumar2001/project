import React from 'react';
import { Carousel } from 'antd';
import image1 from '../../images/slider2.jpg'
import image2 from '../../images/slider6.jpeg'
import image3 from '../../images/slider4.jpg'
import section2 from '../../images/consulting.png'
import section5 from '../../images/leaf.png'
import section1 from '../../images/opportunity (1).png'
import section3 from '../../images/insights.png'
import section4 from '../../images/innovations.png'

import './home.css'
const contentStyle = {
    margin: 0,
    // height: '200px',
    // color: '#fff',
    // lineHeight: '100px',
    // textAlign: 'center',
    // background: '#364d79',
};

const App = () => {
    const onChange = (currentSlide) => {
        console.log(currentSlide);
    };

    return (
        <div>
            <Carousel afterChange={onChange}>
                <div style={contentStyle}>

                    <div className="content-container">
                        <img src={image1} alt="Background" className="content-image" />

                        <div className="overlay">
                            <h1>WHY CHOOSE US?</h1>
                        </div>
                    </div>
                </div>
                <div style={contentStyle}>

                    <div className="content-container">
                        <img src={image2} alt="Background" className="content-image" />

                        <div className="overlay">
                            <h1>ACCELERATING INDIA'S SUSTAINABILITY<br/>THROUGH BIOMASS</h1>
                        </div>
                    </div>
                </div>

                <div style={contentStyle}>

                    <div className="content-container">
                        <img src={image3} alt="Background" className="content-image" />

                        <div className="overlay">
                            <h1 className="p-5">WHAT DO WE DO?</h1><br/>
                            <h4>BioBiz, we are keen to capitalize on India’s rich biodiversity and the availability of large amounts of biomass residues to develop a sustainable bio-economy and attractive business opportunities for diverse stakeholders – farmers, rural stakeholders, end-use industries, entrepreneurs / startups.<br/>

                               As part of a leading climate tech consulting firm, we will provide critical assistance with market intelligence, data-driven analyses, professional networking, and opportunities for relevant stakeholders to get effective visibility.</h4>
                        </div>
                    </div>
                </div>
            </Carousel>
            <div className='row w-100 p-5 ' style={{ backgroundColor: "#D6D6D6" }}>
                <div className='col-8'>
                    <h6 className='fs-5 fw-small '>At BioBiz, we are keen to capitalize on India’s rich biodiversity and the availability of large amounts of biomass residues to develop a sustainable bio-economy and attractive business opportunities for diverse stakeholders – farmers, rural stakeholders, end-use industries, entrepreneurs / startups, and financial investors.<br/>

                        As part of a leading climate tech consulting firm, we will provide critical assistance with market intelligence, data-driven analyses, professional networking, and opportunities for relevant stakeholders to get effective visibility. </h6>
               <div className='row p-3'>
                <h1 className='text-center'>Main Sections</h1>
                 <div className='col-4 p-3'>
                    <img src={section1} className=''/>
                    <h5 className='py-2' >Opportunities</h5>
                 </div>
                 <div className='col-4 p-3'>
                 <img src={section2} className=''/>

                    <h5>Consulting</h5>
                 </div>
                 <div className='col-4 p-3'>
                 <img src={section3} className=''/>

                    <h5>Insights</h5>
                 </div>
                 <div className='col-4 p-3'>
                 <img src={section4} className=''/>

                    <h5>Innovation Sights</h5>
                 </div> <div className='col-4 p-3'>
                 <img src={section5} className=''/>

                    <h5>Biomass Residue Intelligence</h5>
                 </div>
               </div>
                </div>
                
                <div className="col-4 bg-success text-white p-3 rounded" style={{ maxHeight: '60vh', overflowY: 'auto', scrollBehavior: 'smooth' }}>
    <h6 className='fs-1 text-center fw-bold'>India Updates</h6>
    <p>India’s First Cowshed with Integrated CBG Plant Opens in Gwalior</p>
    <p>Biochar Use in Steelmaking Explored as IIT (ISM) Dhanbad Partners with sentra.world</p>
    <p>Ethanol Plant by Kisan Cooperative Sugar Mill in Pilibhit</p>
    <p>World’s Largest Sustainable Aviation Fuel Plants By TruAlt</p>
    <p>Biofuel production from Seaweed Biomass: HPCL partners with Sea6 Energy</p>
    <p>Green Hydrogen Plant in Baddi: Oil India and Himachal Pradesh Power Corporation partner</p>
    <p>Bio-CNG Plants in 2 Cow Shelters by Greater Noida Authority</p>
    <p>Biogas Plant to Be Revived by Faridabad Municipal Corporation</p>
    <p>Straw-Based Biogas Plant Commercialization</p>
    <p>Biofuel from Carbon Dioxide: New Tech Developed by IIT Guwahati</p>
    <p>Biodiesel Deliveries: Aemetis India Completes $103 Million to OMCs</p>
    <p>Green Hydrogen: TKIL Partners with Sohhytec</p>
    <p>Biobutanol Production: Godavari Biorefineries Partners with Catalyxx</p>
    <p>Compressed Biogas Plants Using Cow Dung in Uttar Pradesh</p>
    <p>Steelmaking with Green Hydrogen: SAIL and John Cockerill India Collaborate</p>
    <p>Sustainable Aviation Fuel Facility: BPCL to Launch India’s First by 2027</p>
    <p>Green Hydrogen Solutions: NHPC Partners with GGGI</p>
    <p>India’s First Green Hydrogen Fuel Station Built by Amara Raja Infra in Leh</p>
    <p>Waste Disposal Plant in Rudrapur to Generate Biogas</p>
    <p>Biochar Integration by Tata Steel in India to Reduce Emissions</p>
    
   
   
</div>


            </div>
            
            <div className='p-5' style={{ backgroundColor: "#E06100" }}>
                <h1 className='text-center'>Other Sections                </h1>
                <div className='p-3 d-flex justify-content-evenly'>
                <button type="button" class="btn btn-primary">India Updates</button>
                <button type="button" class="btn btn-primary">Weekly Updates</button>
                <button type="button" class="btn btn-primary">Bring</button>
                <button type="button" class="btn btn-primary">India Biomass Residues</button>
                 </div>
                 <div className='p-4'>
                    <h1 className='fs-3 fw-bold text-center text-white'>BioBiz is a division of Energy Alternatives India (EAI)</h1>
                 </div>
            </div>
            <div className='p-3'>
                <h1 className='text-center fs-5'>Copyright © 2024 BioBiz. All rights reserved.</h1>
            </div>
        </div>
    );
};

export default App;