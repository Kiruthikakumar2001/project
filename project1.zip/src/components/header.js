
import Image from "../images/bio.png"

function Header() {
  return (
<div className="d-flex justify-content-between w-100">
  <nav className="navbar navbar-expand-lg navbar-light bg-light w-100">
    <div className="container-fluid d-flex justify-content-between w-100">
      <img src={Image} width="60px" height="60px" alt="Logo" />

      <button
        className="navbar-toggler"
        type="button"
        data-bs-toggle="collapse"
        data-bs-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span className="navbar-toggler-icon"></span>
      </button>

      <div className="collapse navbar-collapse" id="navbarSupportedContent">
  <ul className="navbar-nav ms-auto mb-2 mb-lg-0">
    <li className="nav-item me-3">
      <a className="nav-link active" href="#">Home</a>
    </li>
    <li className="nav-item me-3">
      <a className="nav-link active" href="#">About</a>
    </li>
    <li className="nav-item me-3">
      <a className="nav-link active" href="#">India Updates</a>
    </li>
    <li className="nav-item me-3">
      <a className="nav-link active" href="#">Opportunities</a>
    </li>
    <li className="nav-item me-3">
      <a className="nav-link active" href="#">BioBiz Consulting</a>
    </li>
    <li className="nav-item me-3">
      <a className="nav-link active" href="#">Innovation Insights</a>
    </li>
    <li className="nav-item me-3">
      <a className="nav-link active" href="#">Insights</a>
    </li>
    <li className="nav-item me-3">
      <a className="nav-link active" href="#">BRING</a>
    </li>
    <li className="nav-item">
      <a className="nav-link active" href="#">Contact</a>
    </li>
  </ul>
</div>

    </div>
  </nav>
</div>



  );
}

export default Header;
