import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.css';
import Header from './components/header'
import Home from './components/home/index.js'
function App() {
  return (
  <div>
    <Header/>
    <Home/>
  </div>
  );
}

export default App;
